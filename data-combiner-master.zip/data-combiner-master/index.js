module.exports = require(__dirname + '/src/combine.index.js');
