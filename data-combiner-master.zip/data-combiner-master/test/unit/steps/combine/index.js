var assert = require('chai').assert;

var combine = require(`${__dirname}/../../../../src/steps/combine`);

describe('combine step', function () {
    require('./add');
    require('./remove');
});
