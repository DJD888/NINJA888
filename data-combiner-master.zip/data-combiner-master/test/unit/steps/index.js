require('./map');
require('./arrayToObject');
require('./dataArrayToObject');
require('./combine');
